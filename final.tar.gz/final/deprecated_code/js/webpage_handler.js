// this function executes our search via an AJAX call
function runSearch( term ) {
    // hide and clear the previous results, if any
    $('#results').hide();
    // $('tbody').empty();

    // transforms all the form parameters into a string we can send to the server
    var frmStr = $('#protein_search').serialize();

    $.ajax({
        url: '../protein_search.cgi',
        dataType: 'json',
        data: frmStr,
        success: function(data, textStatus, jqXHR) {
            console.log(data);
            processJSON(data);
        },
        error: function(jqXHR, textStatus, errorThrown){
            alert("Failed to perform gene search! textStatus: (" + textStatus +
                ") and errorThrown: (" + errorThrown + ")");
        }
    });
}


// this processes a passed JSON structure representing gene matches and draws it
//  to the result table
function processJSON( data ) {
    // set the span that lists the match count
    $('#match_count').text( data.match_count );

    // this will be used to keep track of row identifiers
    var next_row_num = 1;

    // iterate over each match and add a row to the result table for each
    $.each( data.matches, function(i, item) {
        var this_row_id = 'initialTable_row_' + next_row_num++;

        // create a row and append it to the body of the table
        $('<tr/>', { "id" : this_row_id } ).appendTo('#first_body');

        // trigger events if clicking on the table row
        $('#' + this_row_id).click(function () {
            var saved_row_info = item;
            create_second_table(saved_row_info);
        })



        // add the accession column
        $('<td/>', { "text" : item.accession } ).appendTo('#' + this_row_id);

        // add the version column
        $('<td/>', { "text" : item.version } ).appendTo('#' + this_row_id);

        // add the creation_date column
        $('<td/>', { "text" : item.creation_date } ).appendTo('#' + this_row_id);

        // add the update_date column
        $('<td/>', { "text" : item.update_date } ).appendTo('#' + this_row_id);

        // add the protein_name column
        $('<td/>', { "text" : item.protein_name } ).appendTo('#' + this_row_id);

        // add the protein_type column
        $('<td/>', { "text" : item.protein_type } ).appendTo('#' + this_row_id);

        // add the gene_name column
        $('<td/>', { "text" : item.gene_name } ).appendTo('#' + this_row_id);

    });

    // now show the result section that was previously hidden
    $('#results').show();
}

function create_second_table(data, row_number) {
    $('#autocomplete').hide();
    $('#initial_table').hide();
    $('#match_par').hide();
    $('.extra_info_buttons').hide();
    $('.protein_info_buttons').toggle();
    $('#back_button').show();
    $('#second_body').empty();

    $('<tr/>', { "id" : "secondTable_row_1" } ).appendTo('#second_body');

    // add the accession column
    $('<td/>', { "text" : data.accession } ).appendTo('#secondTable_row_1');

    // add the version column
    $('<td/>', { "text" : data.version } ).appendTo('#secondTable_row_1');

    // add the creation_date column
    $('<td/>', { "text" : data.creation_date } ).appendTo('#secondTable_row_1');

    // add the update_date column
    $('<td/>', { "text" : data.update_date } ).appendTo('#secondTable_row_1');

    // add the protein_name column
    $('<td/>', { "text" : data.protein_name } ).appendTo('#secondTable_row_1');

    // add the protein_type column
    $('<td/>', { "text" : data.protein_type } ).appendTo('#secondTable_row_1');

    // add the gene_name column
    $('<td/>', { "text" : data.gene_name } ).appendTo('#secondTable_row_1');

    $('#second_table').show();


}

function perform_queries() {
    /*
    This function saves information about the single protein selected, then sends
    the information to a CGI script via AJAX call which performs SQL queries.
     */

    // if protein_info_buttons are clicked
    $('.protein_info_buttons button').click(function() {
        // info to be sent to CGI script (sql table name and accession number)
        var sql_table = $(this).val();
        var clicked_accession = $('#secondTable_row_1 td:first-child').text();

        // sends information to CGI script
        $.ajax({
                url: '../sql_queries.cgi',
                method: 'POST',
                data: {'sql_table': sql_table, 'accession': clicked_accession},
                dataType: 'json',
                success: function(data) {
                    // empty table
                    $('#protein_info_tr').empty();
                    $('#protein_info_tbody').empty();

                    // hide or show table
                    if ($("#protein_info_table").is(':visible')) {
                        $('#protein_info_table').hide();
                    }
                    else {
                        $('.protein_info').show();
                        $('#protein_info_table').show();
                        $('#protein_info_table thead tr').show();
                    }

                    console.log(data)

                    let row_count = 1

                    // iterate over each match and add a row to the result table for each
                    $.each( data.matches, function(i, item) {
                        var this_row_id = 'info_row_' + row_count++;
                        $('<tr id=' + this_row_id + '></tr>').appendTo('#protein_info_tbody')

                        if (sql_table === "Biological_Functions") {
                            if (i === 0) {
                                $('<td>General Function</td>').appendTo('#protein_info_tr')
                                $('<td>Specific Function</td>').appendTo('#protein_info_tr')
                            }

                            $('<td/>', { "text" : item.general_function }).appendTo('#' + this_row_id)
                            $('<td/>', { "text" : item.uniprot_id }).appendTo('#' + this_row_id)

                        }
                        if (sql_table === "Protein_Properties") {
                            if (i === 0) {
                                $('<td>Residue Number</td>').appendTo('#protein_info_tr')
                                $('<td>Molecular Weight</td>').appendTo('#protein_info_tr')
                                $('<td>Theoretical Isoelectric Point (pI)</td>').appendTo('#protein_info_tr')
                                $('<td>Polypeptide Sequence</td>').appendTo('#protein_info_tr')
                            }

                            $('<td/>', { "text" : item.residue_number }).appendTo('#' + this_row_id)
                            $('<td/>', { "text" : item.molecular_weight }).appendTo('#' + this_row_id)
                            $('<td/>', { "text" : item.theoretical_pi}).appendTo('#' + this_row_id)
                            $('<td/>', { "text" : item.polypeptide_sequence }).appendTo('#' + this_row_id)
                        }

                        if (sql_table === "Gene_Properties") {
                            if (i === 0) {
                                $('<td>Chromosome Location</td>').appendTo('#protein_info_tr')
                                $('<td>Locus</td>').appendTo('#protein_info_tr')
                                $('<td>Gene Sequence</td>').appendTo('#protein_info_tr')
                            }

                            $('<td/>', { "text" : item.chromosome_location }).appendTo('#' + this_row_id)
                            $('<td/>', { "text" : item.locus }).appendTo('#' + this_row_id)
                            $('<td/>', { "text" : item.gene_sequence }).appendTo('#' + this_row_id)
                        }

                        if (sql_table === "Metabolites") {
                            if (i === 0) {
                                $('<td>Metabolite Accession #</td>').appendTo('#protein_info_tr')
                                $('<td>Name</td>').appendTo('#protein_info_tr')
                            }
                            $('<td/>', { "text" : item.metabolite_accession }).appendTo('#' + this_row_id)
                            $('<td/>', { "text" : item.metabolite_name }).appendTo('#' + this_row_id)
                        }

                        if (sql_table === "Pathways") {
                            if (i === 0) {
                                $('<td>Pathway</td>').appendTo('#protein_info_tr')
                            }
                            $('<td/>', { "text" : item.pathway_name }).appendTo('#' + this_row_id)
                        }

                        if (sql_table === "Go_Classifications") {
                            if (i === 0) {
                                $('<td>Category</td>').appendTo('#protein_info_tr')
                                $('<td>Description</td>').appendTo('#protein_info_tr')
                                $('<td>Go ID</td>').appendTo('#protein_info_tr')
                            }
                            $('<td/>', { "text" : item.category }).appendTo('#' + this_row_id)
                            $('<td/>', { "text" : item.description }).appendTo('#' + this_row_id)
                            $('<td/>', { "text" : item.go_id }).appendTo('#' + this_row_id)
                        }

                        if (sql_table === "Additional_Info") {
                            if (i === 0) {
                                $('<td>Genbank ID</td>').appendTo('#protein_info_tr')
                                $('<td>UniProt ID</td>').appendTo('#protein_info_tr')
                            }
                            $('<td/>', { "text" : item.genbank_protein_id }).appendTo('#' + this_row_id)
                            $('<td/>', { "text" : item.uniprot_id }).appendTo('#' + this_row_id)
                        }

                        if (sql_table === "Literature_References") {
                            if (i === 0) {
                                $('<td>Reference</td>').appendTo('#protein_info_tr')
                            }
                            $('<td/>', { "text" : item.reference_text }).appendTo('#' + this_row_id)
                        }
                    });
                },
                error: function(jqXHR, textStatus, errorThrown){
                    alert("Failed to perform gene search! textStatus: (" + textStatus +
                        ") and errorThrown: (" + errorThrown + ")"
                    );
                }
            }
        )
    })
}

// main method
// actions for when page is ready
$(document).ready(function() {
    // // hide results initially
    $("#results").hide();
    $('tbody').empty();
    $('#submit').hide();
    $('#second_table').hide();

    // todo: implement autocompletion function

    // initial front page button toggles
    $('#about_button').click(function() {
        $('.about_button').toggle();
    })
    $('#schema_button').click(function() {
        $('#schema').toggle();
    })

    // main search function
    $('#submit').click(function () {
        runSearch();
        return false;
    })

    // pressing the back button
    $('#back_button').click(function() {
        $('#second_table').hide();
        $('#initial_table').show();
        $('#match_par').show();
        $(this).hide();
        $('.protein_info_buttons').hide();
        $('.extra_info_buttons').show();
    })

    // if pressing buttons after the second table
    perform_queries()


})